#!/bin/bash

python3 code/File-Genx.py
